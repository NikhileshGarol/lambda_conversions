import json
import os

def lambda_handler(event, context):
    # Get environment-specific configuration
    environment = os.environ.get("ENVIRONMENT", "dev")
    video_call_url = os.environ.get("VIDEO_CALL_URL", "https://webrtc1.ddns.net")
    allowed_origin = os.environ.get("ALLOWED_ORIGIN", "*")

    # Standard CORS headers
    headers = {
        "Content-Type": "application/json",
        "Access-Control-Allow-Origin": allowed_origin,
        "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
        "Access-Control-Allow-Headers": "Content-Type, Authorization"
    }

    # Handle CORS preflight
    if event.get("httpMethod") == "OPTIONS":
        return {
            "statusCode": 200,
            "headers": headers,
            "body": json.dumps({"message": "CORS preflight"})
        }

    # Actual GET/POST request
    response_body = {
        "VideoCallURL": video_call_url,
        "environment": environment
    }

    return {
        "statusCode": 200,
        "headers": headers,
        "body": json.dumps(response_body)
    }
